<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="robots" content="index, follow" />
<meta name="keywords" content="аренда, приборы, МЧС, лицензия, получить, перечень" />
<meta name="description" content="У нас можно арендовать приборы для получения лицензии МЧС" />
<link href="/bitrix/cache/css/s1/content/kernel/kernel.css?1450164231" type="text/css" rel="stylesheet" />
<script type="text/javascript"> var arKernelCSS = new Array('/bitrix/js/main/core/css/core.css','/bitrix/js/socialservices/css/ss.css'); </script><link href="/bitrix/cache/css/s1/content/template_e3501e55c2b0bf8eb4c0bd08c4c519b6/template_e3501e55c2b0bf8eb4c0bd08c4c519b6_aceb9981c22d98b900974a136a3c97fd.css?1450091983" type="text/css" rel="stylesheet" />

<script type="text/javascript">if(!window.BX)window.BX={message:function(mess){if(typeof mess=='object') for(var i in mess) BX.message[i]=mess[i]; return true;}};</script><script type="text/javascript">(window.BX||top.BX).message({'LANGUAGE_ID':'ru','FORMAT_DATE':'DD.MM.YYYY','FORMAT_DATETIME':'DD.MM.YYYY HH:MI:SS','COOKIE_PREFIX':'BITRIX_SM','USER_ID':'','SERVER_TIME':'1450687128','SERVER_TZ_OFFSET':'10800','USER_TZ_OFFSET':'0','USER_TZ_AUTO':'Y','bitrix_sessid':'63de922f75df0e1176980e772b733358','SITE_ID':'s1'});(window.BX||top.BX).message({'JS_CORE_LOADING':'Загрузка...','JS_CORE_NO_DATA':'- Нет данных -','JS_CORE_WINDOW_CLOSE':'Закрыть','JS_CORE_WINDOW_EXPAND':'Развернуть','JS_CORE_WINDOW_NARROW':'Свернуть в окно','JS_CORE_WINDOW_SAVE':'Сохранить','JS_CORE_WINDOW_CANCEL':'Отменить','JS_CORE_H':'ч','JS_CORE_M':'м','JS_CORE_S':'с','JSADM_AI_HIDE_EXTRA':'Скрыть лишние','JSADM_AI_ALL_NOTIF':'Показать все','JSADM_AUTH_REQ':'Требуется авторизация!','JS_CORE_WINDOW_AUTH':'Войти','JS_CORE_IMAGE_FULL':'Полный размер'});</script>
<script type="text/javascript" src="/bitrix/cache/js/s1/content/kernel/kernel.js?1450164231"></script>
<script type="text/javascript"> BX.setKernelJS(['/bitrix/js/main/core/core.js','/bitrix/js/main/core/core_ajax.js','/bitrix/js/main/session.js','/bitrix/js/main/core/core_fx.js','/bitrix/js/main/json/json2.min.js','/bitrix/js/main/core/core_ls.js','/bitrix/js/pull/pull.js','/bitrix/js/socialservices/ss.js']); </script><script type="text/javascript">
bxSession.Expand(1440, '63de922f75df0e1176980e772b733358', false, '69b863ef913e0fbd587684ce36d7b7b4');
</script>



 <title>Аренда оборудования для получения лицензии МЧС</title>
<!--[if IE]>
	<script>
		document.createElement('header');
		document.createElement('nav');
		document.createElement('section');
		document.createElement('article');
		document.createElement('aside');
		document.createElement('footer');
        </script>
<![endif]-->
 <!--[if IE]>
      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <![endif]-->
<link rel="stylesheet" type="text/css" href="/bitrix/templates/content/normalize.css">
<link rel="stylesheet" type="text/css" href="/bitrix/templates/content/style.css">
<script src="http://www.nousro.ru/bitrix/templates/content/js/slider1.js" type="text/javascript"></script>

<!-- Add jQuery library -->
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/lib/jquery-1.10.1.min.js"></script>

	<!-- Add mousewheel plugin (this is optional) -->
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>

	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
	<link rel="stylesheet" type="text/css" href="/bitrix/templates/content/fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />

	<!-- Add Button helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="/bitrix/templates/content/fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>

	<!-- Add Thumbnail helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="/bitrix/templates/content/fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>

	<!-- Add Media helper (this is optional) -->
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>

	<script type="text/javascript">
		$(document).ready(function() {
			{
				txt = $('.topkarta').html();
				if(txt) {
					$('.topkarta').remove();
					$('h1').after('<div class="topkarta">'+txt+'</div>');
				}
				txt = $('.topkarta-clear').html();
				if(txt) {
					$('.topkarta-clear').remove();
					$('h1').after('<div class="topkarta-clear">'+txt+'</div>');
				}
			}
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();

			/*
			 *  Different effects
			 */

			// Change title type, overlay closing speed
			$(".fancybox-effects-a").fancybox({
				helpers: {
					title : {
						type : 'outside'
					},
					overlay : {
						speedOut : 0
					}
				}
			});

			// Disable opening and closing animations, change title type
			$(".fancybox-effects-b").fancybox({
				openEffect  : 'none',
				closeEffect	: 'none',

				helpers : {
					title : {
						type : 'over'
					}
				}
			});

			// Set custom style, close if clicked, change title type and overlay color
			$(".fancybox-effects-c").fancybox({
				wrapCSS    : 'fancybox-custom',
				closeClick : true,

				openEffect : 'none',

				helpers : {
					title : {
						type : 'inside'
					},
					overlay : {
						css : {
							'background' : 'rgba(238,238,238,0.85)'
						}
					}
				}
			});

			// Remove padding, set opening and closing animations, close if clicked and disable overlay
			$(".fancybox-effects-d").fancybox({
				padding: 0,

				openEffect : 'elastic',
				openSpeed  : 150,

				closeEffect : 'elastic',
				closeSpeed  : 150,

				closeClick : true,

				helpers : {
					overlay : null
				}
			});

			/*
			 *  Button helper. Disable animations, hide close button, change title type and content
			 */

			$('.fancybox-buttons').fancybox({
				openEffect  : 'none',
				closeEffect : 'none',

				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,

				helpers : {
					title : {
						type : 'inside'
					},
					buttons	: {}
				},

				afterLoad : function() {
					this.title = 'Image ' + (this.index + 1) + ' of ' + this.group.length + (this.title ? ' - ' + this.title : '');
				}
			});


			/*
			 *  Thumbnail helper. Disable animations, hide close button, arrows and slide to next gallery item if clicked
			 */

			$('.fancybox-thumbs').fancybox({
				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,
				arrows    : false,
				nextClick : true,

				helpers : {
					thumbs : {
						width  : 50,
						height : 50
					}
				}
			});

			/*
			 *  Media helper. Group items, disable animations, hide arrows, enable media and button helpers.
			*/
			$('.fancybox-media')
				.attr('rel', 'media-gallery')
				.fancybox({
					openEffect : 'none',
					closeEffect : 'none',
					prevEffect : 'none',
					nextEffect : 'none',

					arrows : false,
					helpers : {
						media : {},
						buttons : {}
					}
				});

			/*
			 *  Open manually
			 */

			$("#fancybox-manual-a").click(function() {
				$.fancybox.open('1_b.jpg');
			});

			$("#fancybox-manual-b").click(function() {
				$.fancybox.open({
					href : 'iframe.html',
					type : 'iframe',
					padding : 5
				});
			});

			$("#fancybox-manual-c").click(function() {
				$.fancybox.open([
					{
						href : '1_b.jpg',
						title : 'My title'
					}, {
						href : '2_b.jpg',
						title : '2nd title'
					}, {
						href : '3_b.jpg'
					}
				], {
					helpers : {
						thumbs : {
							width: 75,
							height: 50
						}
					}
				});
			});


		});
	</script>
<!-- RedHelper -->
<script id="rhlpscrtg" type="text/javascript" charset="utf-8" async="async" 
 src="https://web.redhelper.ru/service/main.js?c=shopap">
</script> 
<!--/Redhelper -->
 <script type="text/javascript">
$(document ).ready(function() {

$('.lupa2').mouseover(function(){

$('.lupa2').attr('src', 'https://psv4.vk.me/c609818/u8831515/docs/2eac33bc1be9/prokhod_lupa.jpg?extra=IEn4zfoOObdfwdfJpaFQMJFczl5SOkZzVBmAd-toBKjW1yXAlm8y6RFkECjuLEu7aaXIO9Uf822TgV3SqmAO2cUN_DBx9wg');


});
$('.lupa2').mouseout(function(){

$('.lupa2').attr('src', 'http://www.nousro.ru/bitrix/templates/main/images/services.png');


});


});


</script> 
 <link href="http://nousro.ru/clients/css/style.css" type="text/css" rel="Stylesheet"></link> 
<script src="http://nousro.ru/clients/js/jquery.mousewheel.min.js" type="text/javascript"></script>
 
<script src="http://nousro.ru/clients/js/jcarousellite-mod.js" type="text/javascript"></script>
 
<script type="text/javascript">
jQuery(function(){
jQuery(".clients").jCarouselLite({
		auto: 2000,
        speed: 1000,
		vertical: true,
		visible: 5,
		scroll:3,
		btnPrev:null,
		btnNext:null,
		mouseWheel:true
    });
});
</script>
</head>
<body onload="slider('slider',0)">
<style>
.blackbg {
	position:fixed;
	width:100%;
	height:100%;
	background:rgba(0, 0, 0, 0.85);
	z-index:100;
	display:none;
}
.zvonok-form {
	position:fixed;
	width:300px;
	height:346px;
	z-index:101;
	background:white;
	left:50%;
	top:50%;
	margin-left:-150px;
	margin-top:-173px;
	display:none;
}
.zvonok-form .title {
	background:#087ccf;
	text-transform:uppercase;
	text-align:center;
	border-bottom:3px solid #ff0e0b;
	color:white;
	padding:8px 0;
	margin:0 0 10px 0;
}
.zvonok-form form {
	padding:10px;
}
.zvonok-form input[type=text] {
	width:100%;
	border:1px solid #087ccf;
}
.zvonok-form textarea {
	width:100%;
	border:1px solid #087ccf;
}
.zvonok-form input[type=submit] {
	cursor:pointer;
	border:0;
	background:#087ccf;
	padding:6px 10px;
	color:white;
}
.zvonok-form input[type=submit]:hover {
	opacity:0.7;
}
.zvonok-form .close {
	cursor:pointer;
	font-family:tahoma;
	background:white;
	position:absolute;
	top:8px;
	right:8px;
	padding:0 5px 4px;
	border-radius:9px;
	line-height:15px;
	font-size:16px;
}
.zvonok-form .close:hover {
	background:#ff0e0b;
	color:white;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
	$('.modalform_zvonok').click(function(){
		$('.blackbg, .zvonok-form').fadeIn(100);
	});
	$('.blackbg,.close').click(function(){
		$('.blackbg, .zvonok-form').fadeOut(100);
	});
});
</script>
<div class="blackbg"></div>
<div class="zvonok-form">
	<div class="close">x</div>
	<div class="title">Обратный звонок</div>
	<form action="/modalforms/" method="post">
		<input type="hidden" name="type" value="zvonok" />
		<label for="name">Имя</label><br />
		<input type="text" name="name" id="name" /><br /><br />
		<label for="phone">Телефон</label><br />
		<input type="text" name="phone" id="phone" /><br /><br />
		<label for="message">Дополнительная информация</label><br />
		<textarea name="message" id="message"></textarea><br /><br />
		<input type="submit" value="Отправить" />
	</form>
</div><style>
.vopros-form {
	position:fixed;
	width:300px;
	height:346px;
	z-index:101;
	background:white;
	left:50%;
	top:50%;
	margin-left:-150px;
	margin-top:-173px;
	display:none;
}
.vopros-form .title {
	background:#087ccf;
	text-transform:uppercase;
	text-align:center;
	border-bottom:3px solid #ff0e0b;
	color:white;
	padding:8px 0;
	margin:0 0 10px 0;
}
.vopros-form form {
	padding:10px;
}
.vopros-form input[type=text] {
	width:100%;
	border:1px solid #087ccf;
}
.vopros-form textarea {
	width:100%;
	border:1px solid #087ccf;
}
.vopros-form input[type=submit] {
	cursor:pointer;
	border:0;
	background:#087ccf;
	padding:6px 10px;
	color:white;
}
.vopros-form input[type=submit]:hover {
	opacity:0.7;
}
.vopros-form .close {
	cursor:pointer;
	font-family:tahoma;
	background:white;
	position:absolute;
	top:8px;
	right:8px;
	padding:0 5px 4px;
	border-radius:9px;
	line-height:15px;
	font-size:16px;
}
.vopros-form .close:hover {
	background:#ff0e0b;
	color:white;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
	$('.modalform_vopros').click(function(){
		$('.blackbg, .vopros-form').fadeIn(100);
	});
	$('.blackbg,.close').click(function(){
		$('.blackbg, .vopros-form').fadeOut(100);
	});
});
</script>
<div class="vopros-form">
	<div class="close">x</div>
	<div class="title">Задать вопрос</div>
	<form action="/modalforms/" method="post">
		<input type="hidden" name="type" value="vopros" />
		<label for="name">Имя</label><br />
		<input type="text" name="name" id="name" /><br /><br />
		<label for="email">Электронная почта для ответа</label><br />
		<input type="text" name="email" id="email" /><br /><br />
		<label for="message">Вопрос</label><br />
		<textarea name="message" id="message"></textarea><br /><br />
		<input type="submit" value="Отправить" />
	</form>
</div>	
		<div class="header">
			<div class="inner">
		<a href="/">	<img src="/bitrix/templates/content/img/logo.png" class="logo" alt=""></a>
			<p style="float: left;"> 
				Негосударственное образовательное учреждение<br>
				 дополнительного профессионального образования<br>
					«МЕЖРЕГИОНАЛЬНЫЙ УЧЕБНЫЙ ЦЕНТР»
			</p>
				
<div class="menu">
<ul>
			<li><a href="/" class="active">Главная</a></li>
		
			<li><a href="/about/">О нас</a></li>
		
			<li><a href="/filial/">Филиалы</a></li>
		
			<li><a href="/about/otkrytaya-informatsiya.php">Открытая информация</a></li>
		
			<li><a href="/contacts/">Контакты</a></li>
		
</ul>
</div>
		</div>
		</div>
<br clear="all">
		<div class="inner">
		<div class="left_block">

			<div class="choose_study">
				<div class="consult">Получить консультацию:</div>
				<a class="modalform_zvonok" onclick="yaCounter15488413.reachGoal('callmebtn'); return true;" href="#">Заказать звонок</a>
				<a class="modalform_vopros" onclick="yaCounter15488413.reachGoal('question'); return true;" href="#">Задать вопрос</a>
			</div>

			<div class="och-dist_left_block_content"> 
<div class="bredcrums"><a title="Главная" href="/" >Главная</a> <font color="#898989">▶</font> <a title="Услуги" href="/service.php" >Услуги</a> <font color="#898989">▶</font> Аренда оборудования для получения лицензии МЧС</div>
 
<h1 style="text-align: center;">Аренда оборудования для получения лицензии МЧС</h1>
 
<p style="text-align: justify;">Наша компания оказывает полный набор услуг для получения лицензии МЧС, в перечень которых входит и <a  onclick="yaCounter15488413.reachGoal('shopap1'); return true;" href="http://shopap.ru/shop/index.php?ukey=auxpage_arenda-mchs" target="_blank" >аренда оборудования для лицензии МЧС <img src="/upload/medialibrary/a83/ssylka.png" title="аренда оборудования для лицензии МЧС" border="0" alt="аренда оборудования для лицензии МЧС" width="10" height="10"  /></a>. Наличие необходимых для произведения монтажа, технического обслуживания и ремонта средств обеспечения пожарной безопасности зданий и сооружений приборов, на ряду с наличием сотрудников с соответствующей подготовкой и удостоверением о повышении квалификации является одним из основных требований в процессе оформления лицензии МЧС.</p>
 
<p style="text-align: justify;">Как в покупке, так и в аренде оборудования <a href="http://www.nousro.ru/mchs-edu.php" title="лицензия мчс " >для лицензии МЧС <img src="/upload/medialibrary/a83/ssylka.png" title="Обучение для лицензии МЧС" border="0" alt="Обучение для лицензии МЧС" width="10" height="10"  /></a> есть свои плюсы и минусы. <strong>Аренда приборов</strong> выгодна с точки зрения финансовых затрат: во-первых, не каждая фирма может позволить себе разом потратить баснословную сумму; во-вторых, даже если Вы можете это себе позволить, то это не значит, что стоит спускать подобные суммы впустую, так как практика показывает, что далеко не все оборудование пригодится Вам в работе. Так же, при аренде оборудования у нас, мы берем на себя все заботы о поддержании приборов в надлежащем рабочем состоянии. Наши приборы и средства измерений технически исправны, введены в эксплуатацию в 2015 году, имеют диапазоны измерений в соответствии с руководящими документами, внесены в Государственный реестр средств измерений и должным образом поверены. Кроме того, мы предоставляем всю необходимую документацию: товарные накладные, технические паспорта.</p>
 <br/>
<center><img src="pochemy_my.jpg" title="наши преимущества"/></center>
<br/>
<h2 style="text-align: justify;">Перечень оборудования для лицензии МЧС</h2>
 
<p style="text-align: justify;">Мы осуществляем как продажу, так и аренду приборов. Договор аренды прибора является законным основанием для успешного прохождения лицензирования, у инспектора МЧС не будет к Вам претензий, если у Вас есть все необходимые приборы, как в собственности, так и на правах аренды. Другой, более сложный вопрос заключается в том, что не существует четкого списка оборудования для получения лицензии МЧС.</p>
 
<p style="text-align: justify;">Во многом это происходит из-за того, что соответствующие органы не спешат тестировать современное высокоточное технологичное оборудование для лицензии МЧС, а это значит, что Вы не найдете его в ГОСТе и СНиПах и при лицензировании инспектор сочтет его неподходящим. </p>
 
<p style="text-align: justify;"><b>Однако не спешите отчаиваться!</b></p>
 
<p> </p>
 
<div style="text-align: justify;">Мы поможем Вам сделать правильный выбор! Заходите в наш <a  onclick="yaCounter15488413.reachGoal('shopap1'); return true;" href="http://shopap.ru" target="_blank" >интернет-магазин <img src="/upload/medialibrary/a83/ssylka.png" title="взять оборудование для лицензии МЧС" border="0" alt="взять оборудование для лицензии МЧС" width="10" height="10"  /></a>, и наши специалисты сориентируют Вас по необходимому оборудованию! </div>
 
<div style="text-align: justify;">Вне зависимости от того, где зарегистрирована Ваша организация, при обращении к нам Вас ждут низкие цены и доброжелательное отношение! Кроме того, Вы можете выбрать один из следующих способов доставки:</div>
 
<p></p>
 
<img src="delivery.jpg" title="Доставка оборудования для получения лицензии МЧС своим транспортом прямо к Вам в офис (по предварительному согласованию)" width="620"/>
 
<p style="text-align: justify;">Мы ждем Ваших обращений!</p>

 ﻿</div>

		</div>

		<div class="right_block">
				<a href="http://nousro.ru/contacts/"><span class="cont">+7 (495) 721-02-69 &nbsp; +7 (495) 780-79-93<br>
			Skype: mucdpo &nbsp; E-mail: info@nousro.ru
			</span>
			<a href="http://nousro.ru/contacts/"><img src="/bitrix/templates/content/img/phone_img.png" alt="" class="phone_img"></a>
<br />
									
			
			
			
			
						
			
						
						
						
						
			
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
			
						
						
						
						
						
						
						<div class="right_block1">
				<a href="/program.php"><p class="right_choose_kursi" class="choose_btn">курсы</p></a>
				<a href="/service.php"> <p class="right_choose_uslugi" class="choose_btn"> услуги</p></a>
					<ul class="right_block1_ul1">
						<li><a href="/program-ptm.php">ПТМ</a></li>
						<li><a href="/pojarbez.php">Пожарная безопасность</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/">Охрана труда</a></li>
						<li><a href="/stroi.php">Строительство</a></li>
						<li><a href="/jekologija.php">Экологическая безопасность</a></li>
						<li><a href="/proektirovanie.php">Проектирование</a></li>
						<li><a href="/gochs.php">Обучение ГО и ЧС</a></li>

					</ul>
					<ul class="right_block1_ul2">
						<li><a href="/mchs-edu.php">Обучение для лицензии МЧС</a></li>
						<li><a href="/licenzija-mchs.php">Лицензия МЧС</a></li>
						<li><a href="/arenda.php">Аренда оборудования МЧС</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/outsourcing-ohrana-truda.html">Аутсорсинг по охране труда</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/ohrana-truda.html">Организация охраны труда</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/attestacija-rabochih-mest.html">Оценка условий труда</a></li>
						<li><a href="/arenda-fstek.php">Оборудование для ФСТЭК</a></li>
						<li><a href="/perepodgotovka-specialistov.php">Переобучение специалистов</a></li>
											</ul>
				
			</div>
			            <div class="right_block3">
				<div class="kursi_btn1"><a href="/request/" onclick="yaCounter15488413.reachGoal('zayonline'); return true;" >ЗАЯВКА НА КУРСЫ <em>online</em></a></div>
				<div class="kursi_btn2"><a href="/upload/learning/zayavka.doc">ЗАЯВКА НА КУРСЫ <em>скачать</em></a></div>
				<img src="/bitrix/templates/content/img/paper_clip_icon.png"  style = "display: none";>
			</div>
			
			<div class="right_block2">
				<a href="/checkuser/">!&nbsp;&nbsp;&nbsp; ВЫДАННЫЕ УДОСТОВЕРЕНИЯ&nbsp;&nbsp;&nbsp; !</a></p>
			</div>
            <div class="right_block3">
				<div class="kursi_btn1"><a href="/clients/" onclick="yaCounter15488413.reachGoal('ourclients'); return true;" >НАШИ КЛИЕНТЫ</a></div>
				<div class="kursi_btn2"><a href="/clients/otzyvy.php" onclick="yaCounter15488413.reachGoal('otzyvy-btn'); return true;">ОТЗЫВЫ О НАС</a></div>
				
			</div>

			

			<div class="right_block4" style="cursor:pointer;" onclick="location.href='/doc/'; yaCounter15488413.reachGoal('shopap1'); return true;" > 
				<a href="/doc/">Учредительные<br>документы</a>
			</div>

			<div class="right_block5">
				<a href="/portal-postavchikov.php"><img src="/bitrix/templates/content/img/icon_block.jpg" alt=""></a>
			</div>

			<div class="right_block6">
			<a  onclick="yaCounter15488413.reachGoal('btn-karta'); return true;" href="/bitrix/templates/content/img/2map.jpg"  class="fancybox" data-fancybox-group="gallery"><img src="/bitrix/templates/content/img/icon_map.jpg" class="lupa" alt=""></a>
			</div>

			<div class="right_block7">
				<a href="/fotovideo.php"><img src="/bitrix/templates/content/img/fotobtn.png" alt=""></a>
			</div>

		</div>
		</div>

		<div class="footer_och-dist">
			<div class="inner">
				<div class="footer_items"><h3>Разделы сайта</h3>
					<ul>
						<li><a href="/">-Главная</a></li>
						<li><a href="/about/">-О нас</a></li>
						<li><a href="/filial/">-Филиалы</a></li>
						<li><a href="/clients/">-Клиенты</a></li>
						<li><a href="/doc/">-Документы</a></li>
						<li><a href="/faq/">-Вопрос-ответ</a></li>
						<li><a href="/sitemap/">-Карта сайта</a></li>
					</ul>
				</div>

				<div class="footer_items"><h3>Курсы</h3>
					<ul>
						<li><a href="/program-ptm.php">-ПТМ</a></li>
						<li><a href="/pojarbez.php">-Пожарная безопасность</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/">-Охрана труда</a></li>
						<li><a href="/stroi.php">-Строительство</a></li>
						<li><a href="/jekologija.php">-Экологическая безопасность</a></li>
						<li><a href="/proektirovanie.php">-Проектирование</a></li>
					</ul>
				</div>

				<div class="footer_items"><h3>Услуги</h3>
					<ul>
						<li><a href="/mchs-edu.php">-Обучение для лицензии МЧС</a></li>
						<li><a href="/licenzija-mchs.php">-Лицензия МЧС</a></li>
						<li><a href="/arenda.php">-Аренда оборудования МЧС</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/outsourcing-ohrana-truda.html">-Аутсорсинг по охране труда</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/ohrana-truda.html">-Организация охраны труда</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/attestacija-rabochih-mest.html">-Специальная оценка условий труда</a></li>
						<li><a href="/arenda-fstek.php">-Аренда оборудования для ФСТЭК</a></li>		
					</ul>
				</div>

				<div class="footer_items"><h3>Документы</h3>
					<ul>
						<li><a href="/upload/doc/rbot/licenzija_obuchenija.pdf">-Лицензия НОЧУ ДПО "МУЦ"</a></li>
						<li><a href="/upload/doc/soglasovanije.pdf">-Согласование</a></li>
						<li><a href="/upload/doc/rbot/ustav_nou.pdf">-Устав НОЧУ ДПО "МУЦ"</a></li>
						<li><a href="/upload/doc/rbot/polojenie.pdf">-Положение НОЧУ ДПО "МУЦ"</a></li>
						<li><a href="/upload/doc/rbot/simvolika.pdf">-Символика НОЧУ ДПО "МУЦ"</a></li>
						<li><a href="/upload/doc/rbot/zakljuchenie_gpn.pdf">-Заключение ГПН</a></li>
						<li><a href="/upload/doc/rbot/zakljuchenie_sjez.pdf">-Санитарно-эпидемиологическое заключение</a></li>
						<li><a href="/doc/">-Список всех документов</a></li>
					</ul>
				</div>

				<div class="footer_items"><h3 class="h_social">МЫ В СОЦИАЛЬНЫХ СЕТЯХ</h3>
			
<br/>
			<table style="padding-top:12px;" width="200"><tr><td align="center" width="33%"><a target="_blank" href="https://plus.google.com/109379877916865389941/about"><img src="/bitrix/templates/content/img/google.png" width="20"></a></td><td align="center" width="33%"><a target="_blank" href="https://vk.com/nousro"><img src="/bitrix/templates/content/img/vk.png" width="20"></a></td><td align="center" width="33%"><a target="_blank" href="https://twitter.com/dpomuc"><img src="/bitrix/templates/content/img/twit.png" width="20"></a></td></tr></table>

		</div>
		
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'buevUrygEY';
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);})();</script>
<!-- {/literal} END JIVOSITE CODE -->
<!-- begin of Top100 code -->

 
  <div style="float: left;"> 
<script id="top100Counter" type="text/javascript" src="http://counter.rambler.ru/top100.jcn?2527820"></script>
 <noscript> <a href="http://top100.rambler.ru/navi/2527820/" > <img src="http://counter.rambler.ru/top100.cnt?2527820" alt="Rambler's Top100" border="0"  /> </a> </noscript> 
 
<!-- end of Top100 code -->
				        <!-- Yandex.Metrika informer -->
<a href="https://metrika.yandex.ru/stat/?id=15488413&amp;from=informer"
target="_blank" rel="nofollow"><img src="//bs.yandex.ru/informer/15488413/3_1_FFFFFFFF_EFEFEFFF_0_pageviews"
style="width:88px; height:31px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (просмотры, визиты и уникальные посетители)" onclick="try{Ya.Metrika.informer({i:this,id:15488413,lang:'ru'});return false}catch(e){}"/></a>
<!-- /Yandex.Metrika informer -->

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter15488413 = new Ya.Metrika({id:15488413,
                    webvisor:true,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true});
        } catch(e) { }
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/15488413" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
  </div>
			
		</div>
	</div>
</body>
</html>