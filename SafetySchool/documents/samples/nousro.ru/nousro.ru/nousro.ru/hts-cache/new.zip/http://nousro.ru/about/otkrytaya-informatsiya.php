<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="robots" content="index, follow" />
<meta name="keywords" content="учебный центр, обучение, программы обучения, повышение квалификации" />
<meta name="description" content="Мы профессиональный учебный центр, занимающийся обучением и повышением квалификации рабочих, специалистов и руководителей" />
<link href="/bitrix/cache/css/s1/content/kernel/kernel.css?1450164231" type="text/css" rel="stylesheet" />
<script type="text/javascript"> var arKernelCSS = new Array('/bitrix/js/main/core/css/core.css','/bitrix/js/socialservices/css/ss.css'); </script><link href="/bitrix/cache/css/s1/content/template_e3501e55c2b0bf8eb4c0bd08c4c519b6/template_e3501e55c2b0bf8eb4c0bd08c4c519b6_aceb9981c22d98b900974a136a3c97fd.css?1450091983" type="text/css" rel="stylesheet" />

<script type="text/javascript">if(!window.BX)window.BX={message:function(mess){if(typeof mess=='object') for(var i in mess) BX.message[i]=mess[i]; return true;}};</script><script type="text/javascript">(window.BX||top.BX).message({'LANGUAGE_ID':'ru','FORMAT_DATE':'DD.MM.YYYY','FORMAT_DATETIME':'DD.MM.YYYY HH:MI:SS','COOKIE_PREFIX':'BITRIX_SM','USER_ID':'','SERVER_TIME':'1450687110','SERVER_TZ_OFFSET':'10800','USER_TZ_OFFSET':'0','USER_TZ_AUTO':'Y','bitrix_sessid':'63de922f75df0e1176980e772b733358','SITE_ID':'s1'});(window.BX||top.BX).message({'JS_CORE_LOADING':'Загрузка...','JS_CORE_NO_DATA':'- Нет данных -','JS_CORE_WINDOW_CLOSE':'Закрыть','JS_CORE_WINDOW_EXPAND':'Развернуть','JS_CORE_WINDOW_NARROW':'Свернуть в окно','JS_CORE_WINDOW_SAVE':'Сохранить','JS_CORE_WINDOW_CANCEL':'Отменить','JS_CORE_H':'ч','JS_CORE_M':'м','JS_CORE_S':'с','JSADM_AI_HIDE_EXTRA':'Скрыть лишние','JSADM_AI_ALL_NOTIF':'Показать все','JSADM_AUTH_REQ':'Требуется авторизация!','JS_CORE_WINDOW_AUTH':'Войти','JS_CORE_IMAGE_FULL':'Полный размер'});</script>
<script type="text/javascript" src="/bitrix/cache/js/s1/content/kernel/kernel.js?1450164231"></script>
<script type="text/javascript"> BX.setKernelJS(['/bitrix/js/main/core/core.js','/bitrix/js/main/core/core_ajax.js','/bitrix/js/main/session.js','/bitrix/js/main/core/core_fx.js','/bitrix/js/main/json/json2.min.js','/bitrix/js/main/core/core_ls.js','/bitrix/js/pull/pull.js','/bitrix/js/socialservices/ss.js']); </script><script type="text/javascript">
bxSession.Expand(1440, '63de922f75df0e1176980e772b733358', false, '69b863ef913e0fbd587684ce36d7b7b4');
</script>



 <title>Межрегиональный учебный центр о нас</title>
<!--[if IE]>
	<script>
		document.createElement('header');
		document.createElement('nav');
		document.createElement('section');
		document.createElement('article');
		document.createElement('aside');
		document.createElement('footer');
        </script>
<![endif]-->
 <!--[if IE]>
      <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <![endif]-->
<link rel="stylesheet" type="text/css" href="/bitrix/templates/content/normalize.css">
<link rel="stylesheet" type="text/css" href="/bitrix/templates/content/style.css">
<script src="http://www.nousro.ru/bitrix/templates/content/js/slider1.js" type="text/javascript"></script>

<!-- Add jQuery library -->
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/lib/jquery-1.10.1.min.js"></script>

	<!-- Add mousewheel plugin (this is optional) -->
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>

	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
	<link rel="stylesheet" type="text/css" href="/bitrix/templates/content/fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />

	<!-- Add Button helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="/bitrix/templates/content/fancybox/source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>

	<!-- Add Thumbnail helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="/bitrix/templates/content/fancybox/source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>

	<!-- Add Media helper (this is optional) -->
	<script type="text/javascript" src="/bitrix/templates/content/fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>

	<script type="text/javascript">
		$(document).ready(function() {
			{
				txt = $('.topkarta').html();
				if(txt) {
					$('.topkarta').remove();
					$('h1').after('<div class="topkarta">'+txt+'</div>');
				}
				txt = $('.topkarta-clear').html();
				if(txt) {
					$('.topkarta-clear').remove();
					$('h1').after('<div class="topkarta-clear">'+txt+'</div>');
				}
			}
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();

			/*
			 *  Different effects
			 */

			// Change title type, overlay closing speed
			$(".fancybox-effects-a").fancybox({
				helpers: {
					title : {
						type : 'outside'
					},
					overlay : {
						speedOut : 0
					}
				}
			});

			// Disable opening and closing animations, change title type
			$(".fancybox-effects-b").fancybox({
				openEffect  : 'none',
				closeEffect	: 'none',

				helpers : {
					title : {
						type : 'over'
					}
				}
			});

			// Set custom style, close if clicked, change title type and overlay color
			$(".fancybox-effects-c").fancybox({
				wrapCSS    : 'fancybox-custom',
				closeClick : true,

				openEffect : 'none',

				helpers : {
					title : {
						type : 'inside'
					},
					overlay : {
						css : {
							'background' : 'rgba(238,238,238,0.85)'
						}
					}
				}
			});

			// Remove padding, set opening and closing animations, close if clicked and disable overlay
			$(".fancybox-effects-d").fancybox({
				padding: 0,

				openEffect : 'elastic',
				openSpeed  : 150,

				closeEffect : 'elastic',
				closeSpeed  : 150,

				closeClick : true,

				helpers : {
					overlay : null
				}
			});

			/*
			 *  Button helper. Disable animations, hide close button, change title type and content
			 */

			$('.fancybox-buttons').fancybox({
				openEffect  : 'none',
				closeEffect : 'none',

				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,

				helpers : {
					title : {
						type : 'inside'
					},
					buttons	: {}
				},

				afterLoad : function() {
					this.title = 'Image ' + (this.index + 1) + ' of ' + this.group.length + (this.title ? ' - ' + this.title : '');
				}
			});


			/*
			 *  Thumbnail helper. Disable animations, hide close button, arrows and slide to next gallery item if clicked
			 */

			$('.fancybox-thumbs').fancybox({
				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,
				arrows    : false,
				nextClick : true,

				helpers : {
					thumbs : {
						width  : 50,
						height : 50
					}
				}
			});

			/*
			 *  Media helper. Group items, disable animations, hide arrows, enable media and button helpers.
			*/
			$('.fancybox-media')
				.attr('rel', 'media-gallery')
				.fancybox({
					openEffect : 'none',
					closeEffect : 'none',
					prevEffect : 'none',
					nextEffect : 'none',

					arrows : false,
					helpers : {
						media : {},
						buttons : {}
					}
				});

			/*
			 *  Open manually
			 */

			$("#fancybox-manual-a").click(function() {
				$.fancybox.open('1_b.jpg');
			});

			$("#fancybox-manual-b").click(function() {
				$.fancybox.open({
					href : 'iframe.html',
					type : 'iframe',
					padding : 5
				});
			});

			$("#fancybox-manual-c").click(function() {
				$.fancybox.open([
					{
						href : '1_b.jpg',
						title : 'My title'
					}, {
						href : '2_b.jpg',
						title : '2nd title'
					}, {
						href : '3_b.jpg'
					}
				], {
					helpers : {
						thumbs : {
							width: 75,
							height: 50
						}
					}
				});
			});


		});
	</script>
<!-- RedHelper -->
<script id="rhlpscrtg" type="text/javascript" charset="utf-8" async="async" 
 src="https://web.redhelper.ru/service/main.js?c=shopap">
</script> 
<!--/Redhelper -->
 <script type="text/javascript">
$(document ).ready(function() {

$('.lupa2').mouseover(function(){

$('.lupa2').attr('src', 'https://psv4.vk.me/c609818/u8831515/docs/2eac33bc1be9/prokhod_lupa.jpg?extra=IEn4zfoOObdfwdfJpaFQMJFczl5SOkZzVBmAd-toBKjW1yXAlm8y6RFkECjuLEu7aaXIO9Uf822TgV3SqmAO2cUN_DBx9wg');


});
$('.lupa2').mouseout(function(){

$('.lupa2').attr('src', 'http://www.nousro.ru/bitrix/templates/main/images/services.png');


});


});


</script> 
 <link href="http://nousro.ru/clients/css/style.css" type="text/css" rel="Stylesheet"></link> 
<script src="http://nousro.ru/clients/js/jquery.mousewheel.min.js" type="text/javascript"></script>
 
<script src="http://nousro.ru/clients/js/jcarousellite-mod.js" type="text/javascript"></script>
 
<script type="text/javascript">
jQuery(function(){
jQuery(".clients").jCarouselLite({
		auto: 2000,
        speed: 1000,
		vertical: true,
		visible: 5,
		scroll:3,
		btnPrev:null,
		btnNext:null,
		mouseWheel:true
    });
});
</script>
</head>
<body onload="slider('slider',0)">
<style>
.blackbg {
	position:fixed;
	width:100%;
	height:100%;
	background:rgba(0, 0, 0, 0.85);
	z-index:100;
	display:none;
}
.zvonok-form {
	position:fixed;
	width:300px;
	height:346px;
	z-index:101;
	background:white;
	left:50%;
	top:50%;
	margin-left:-150px;
	margin-top:-173px;
	display:none;
}
.zvonok-form .title {
	background:#087ccf;
	text-transform:uppercase;
	text-align:center;
	border-bottom:3px solid #ff0e0b;
	color:white;
	padding:8px 0;
	margin:0 0 10px 0;
}
.zvonok-form form {
	padding:10px;
}
.zvonok-form input[type=text] {
	width:100%;
	border:1px solid #087ccf;
}
.zvonok-form textarea {
	width:100%;
	border:1px solid #087ccf;
}
.zvonok-form input[type=submit] {
	cursor:pointer;
	border:0;
	background:#087ccf;
	padding:6px 10px;
	color:white;
}
.zvonok-form input[type=submit]:hover {
	opacity:0.7;
}
.zvonok-form .close {
	cursor:pointer;
	font-family:tahoma;
	background:white;
	position:absolute;
	top:8px;
	right:8px;
	padding:0 5px 4px;
	border-radius:9px;
	line-height:15px;
	font-size:16px;
}
.zvonok-form .close:hover {
	background:#ff0e0b;
	color:white;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
	$('.modalform_zvonok').click(function(){
		$('.blackbg, .zvonok-form').fadeIn(100);
	});
	$('.blackbg,.close').click(function(){
		$('.blackbg, .zvonok-form').fadeOut(100);
	});
});
</script>
<div class="blackbg"></div>
<div class="zvonok-form">
	<div class="close">x</div>
	<div class="title">Обратный звонок</div>
	<form action="/modalforms/" method="post">
		<input type="hidden" name="type" value="zvonok" />
		<label for="name">Имя</label><br />
		<input type="text" name="name" id="name" /><br /><br />
		<label for="phone">Телефон</label><br />
		<input type="text" name="phone" id="phone" /><br /><br />
		<label for="message">Дополнительная информация</label><br />
		<textarea name="message" id="message"></textarea><br /><br />
		<input type="submit" value="Отправить" />
	</form>
</div><style>
.vopros-form {
	position:fixed;
	width:300px;
	height:346px;
	z-index:101;
	background:white;
	left:50%;
	top:50%;
	margin-left:-150px;
	margin-top:-173px;
	display:none;
}
.vopros-form .title {
	background:#087ccf;
	text-transform:uppercase;
	text-align:center;
	border-bottom:3px solid #ff0e0b;
	color:white;
	padding:8px 0;
	margin:0 0 10px 0;
}
.vopros-form form {
	padding:10px;
}
.vopros-form input[type=text] {
	width:100%;
	border:1px solid #087ccf;
}
.vopros-form textarea {
	width:100%;
	border:1px solid #087ccf;
}
.vopros-form input[type=submit] {
	cursor:pointer;
	border:0;
	background:#087ccf;
	padding:6px 10px;
	color:white;
}
.vopros-form input[type=submit]:hover {
	opacity:0.7;
}
.vopros-form .close {
	cursor:pointer;
	font-family:tahoma;
	background:white;
	position:absolute;
	top:8px;
	right:8px;
	padding:0 5px 4px;
	border-radius:9px;
	line-height:15px;
	font-size:16px;
}
.vopros-form .close:hover {
	background:#ff0e0b;
	color:white;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
	$('.modalform_vopros').click(function(){
		$('.blackbg, .vopros-form').fadeIn(100);
	});
	$('.blackbg,.close').click(function(){
		$('.blackbg, .vopros-form').fadeOut(100);
	});
});
</script>
<div class="vopros-form">
	<div class="close">x</div>
	<div class="title">Задать вопрос</div>
	<form action="/modalforms/" method="post">
		<input type="hidden" name="type" value="vopros" />
		<label for="name">Имя</label><br />
		<input type="text" name="name" id="name" /><br /><br />
		<label for="email">Электронная почта для ответа</label><br />
		<input type="text" name="email" id="email" /><br /><br />
		<label for="message">Вопрос</label><br />
		<textarea name="message" id="message"></textarea><br /><br />
		<input type="submit" value="Отправить" />
	</form>
</div>	
		<div class="header">
			<div class="inner">
		<a href="/">	<img src="/bitrix/templates/content/img/logo.png" class="logo" alt=""></a>
			<p style="float: left;"> 
				Негосударственное образовательное учреждение<br>
				 дополнительного профессионального образования<br>
					«МЕЖРЕГИОНАЛЬНЫЙ УЧЕБНЫЙ ЦЕНТР»
			</p>
				
<div class="menu">
<ul>
			<li><a href="/">Главная</a></li>
		
			<li><a href="/about/">О нас</a></li>
		
			<li><a href="/filial/">Филиалы</a></li>
		
			<li><a href="/about/otkrytaya-informatsiya.php" class="active">Открытая информация</a></li>
		
			<li><a href="/contacts/">Контакты</a></li>
		
</ul>
</div>
		</div>
		</div>
<br clear="all">
		<div class="inner">
		<div class="left_block">

			<div class="choose_study">
				<div class="consult">Получить консультацию:</div>
				<a class="modalform_zvonok" onclick="yaCounter15488413.reachGoal('callmebtn'); return true;" href="#">Заказать звонок</a>
				<a class="modalform_vopros" onclick="yaCounter15488413.reachGoal('question'); return true;" href="#">Задать вопрос</a>
			</div>

			<div class="och-dist_left_block_content"> 
<div class="bredcrums"><a title="Главная" href="/" >Главная</a> <font color="#898989">▶</font>Сведения о НОЧУ ДПО МУЦ</div>
 
<br />
 <h1>Сведения о НОЧУ ДПО МУЦ</h1> 

 <h2>1. Основные сведения</h2>
<p style="text-align: justify;"> <strong>Негосударственное образовательное учреждение 				дополнительного профессионального образования &quot;Межрегиональный 				учебный центр&quot; (НОЧУ ДПО &quot;МУЦ&quot;)</strong> создано при Саморегулируемой 				организации Некоммерческом партнерстве &quot;Межрегиональное 				объединение организаций в области пожарной безопасности&quot; (СРО 				НП &quot;МОО ПБ&quot;).</p>
 

 
<ul> 
<li style="text-align: justify;">02.08.2011 года получено свидетельство о внесении в ЕГРЮЛ. <a href="/about/sobstveniki.pdf" target="_blank" rel="nofollow" >Информация об учредителях <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
 </ul>
 
 <ul> 
<li style="text-align: justify;">Учебный центр находится по адресу 107564, Краснобогатырская улица, дом 19А. Время работы с 9:00-18:00 с понедельника по пятницу. <a href="http://nousro.ru/contacts/" target="_blank"> Контактная информация электронная почта главного офиса и филиалов. <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
 </ul>
 <ul> 
<li style="text-align: justify;">Учебный центр производит обучение и повышение квалификации по следующим <a href="http://nousro.ru/program.php" target="_blank">программам и курсам <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
 </ul>
  
 <ul> 
<li style="text-align: justify;">Руководителем московского учебного центра является Семенова Екатерина Петровна; </br>
Руководителем Крымского представительства является Вашуркина Галина Евгеньевна;</br>
Руководителем Нижегородского филиала является Верещагин Даниил Серегевич;</br>
Руководителем Филиала в Санкт-Петербурге является Панкова Ирина Петровна;</br>
<a href="http://nousro.ru/filial/" target="_blank">Подробнее о филиалах</a>
</li>
 </ul>
 <h2>2. Структура и органы управления образовательной организацией</h2>
 <ul> 
<li style="text-align: justify;">Главный офис находится в городе Москва, руководителем данного центра является Семенова Екатерина Петровна. <br/>
Сайт организации <a href="http://nousro.ru" target="_blank">nousro.ru</a></br>
Электронная почта info@nousro.ru </br>
<a href="http://nousro.ru/upload/doc/rbot/polojenie.pdf" target="_blank">Положение НОЧУ ДПО "МУЦ" <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /> </a>
 </li>
 </ul>
 <ul> 
 <li style="text-align: justify;">Филиал в Санкт-Петербурге подчиняется головному офису в городе Москва, руководителем данного филиала является Панкова Ирина Петровна  <br/>
Сайт организации <a href="http://nousro-spb.ru/" target="_blank">www.nousro-spb.ru</a></br>
Электронная почта spb@apreal.ru </br>
<a href="http://nousro.ru/upload/doc/rbot/pologenie-spb.pdf" target="_blank">Положение о филиале в Санкт-Петербурге НОЧУ ДПО "МУЦ" <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /> </a>
 </li>
 </ul>
 <ul> 
 <li style="text-align: justify;">Филиал в Нижнем Новгороде подчиняется головному офису в городе Москва, руководителем данного филиала является Верещагин Даниил Серегевич. <br/>
Сайт организации <a href="http://www.nousro-nn.ru/" target="_blank">www.nousro-nn.ru </a></br>
Электронная почта info@apreal-nn.ru </br>
<a href="http://nousro.ru/upload/doc/rbot/pologenie-nn.pdf" target="_blank">Положение о филиале в Нижнем Новгороде НОЧУ ДПО "МУЦ" <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a>
 </li>
 </ul>
  <ul> 
 <li style="text-align: justify;">Представительство в Симферополе подчиняется головному офису в городе Москва, руководителем данного представительства является Вашуркина Галина Евгеньевна. <br/>
Сайт организации <a href="http://ed-crimea.ru/" target="_blank">ed-crimea.ru</a></br>
Электронная почта info@ed-crimea.ru </br>

 </li>
 </ul>
 
 <h2>3. Документы</h2>
 
 <p style="text-align: justify;">С переченем докуентов вы можете ознакомиться в разделе <a href="http://nousro.ru/doc/" target="_blank"> документы  <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></p>
<a href="http://nousro.ru/about/poloshenie nochu.pdf" target="_blank">Положение об образовательном учреждении <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></p>
 
 <h2>4. Образование</h2>
 В нашем учебном центре есть возможность очного и дистанционного обучения. Все программы проводят на русском языке.
 При выборе дистанционной формы все обучение проходит посредством личного кабинета, в котором предоставлены все необходимые материалы для получения знаний а также их проверки. Войти в него можно с <a href="http://nousro.ru" target="_blank">главной страницы <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></p>
 При выборе очной формы занятия проводятся в классе с полным перечнем курсов можно ознакомится на <a href="http://nousro.ru/program.php" target="_blank">странице курсы <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /> </a></p>

  <h2>5. Образовательные стандарты</h2>
    <ul> 
 <li style="text-align: justify;"><a href="http://xn--80abucjiibhv9a.xn--p1ai/%D0%B4%D0%BE%D0%BA%D1%83%D0%BC%D0%B5%D0%BD%D1%82%D1%8B/543" target="_blank">Федеральные государственные образовательные стандарты общего образования <img src="/upload/medialibrary/a83/ssylka.png" title="Федеральные государственные образовательные стандарты общего образования" border="0" alt="Федеральные государственные образовательные стандарты общего образования" width="10" height="10"  /></a> <a href="http://xn--80abucjiibhv9a.xn--p1ai/%D0%B4%D0%BE%D0%BA%D1%83%D0%BC%D0%B5%D0%BD%D1%82%D1%8B/336" target="_blank">
 </li>
 </ul>
 </br> <ul>
<li style="text-align: justify;">Образовательные стандарты <img src="/upload/medialibrary/a83/ssylka.png" title="образовательные стандарты" border="0" alt=" образовательные стандарты  " width="10" height="10"  /></a>
  </li>
 </ul>
  
<h2>6. Руководство. Педагогический (научно-педагогический) состав</h2>
<style>
.prepod td {padding:8px 5px;border:1px solid silver;}
</style>
<table class="prepod">
	<tr>
		<td><b>Дата рождения</b></td>
		<td><b>Образование</b></td>
		<td><b>Преподаваемый предмет, дисциплина</b></td>
		<td><b>Должность по штатному расписанию</b></td>
	</tr>
	<tr>
		<td colspan="4">
			<b>Никулин Михаил Иванович</b>
		</td>
	</tr>
	<tr>
		<td>24.10.1960</td>
		<td>Московский институт пожарной безопасности МВД России 20 июня 1997 г. специальность: «Пожарная безопасность»</td>
		<td>«Монтаж, техническое обслуживание и ремонт средств обеспечения пожарной безопасности зданий и сооружений»</td>
		<td>Педагог</td>
	</tr>
	<tr>
		<td colspan="4">
			<b>Семенов Альберт Борисович</b>
		</td>
	</tr>
	<tr>
		<td>06.12.1973</td>
		<td>Камышинское высшее военное командно-инженерное строительное училище 15 июня 1995 по специальности: Инженер по эксплуатации систем электроснабжения</td>
		<td>«Проектирование зданий и сооружений 1 и 2 уровень ответственности» , «Строительство зданий и сооружений 1 и 2 уровень ответственности»</td>
		<td>Педагог</td>
	</tr>
	<tr>
		<td colspan="4">
			<b>Реган Александр Васильевич</b>
		</td>
	</tr>
	<tr>
		<td>20.08.1965</td>
		<td>Житомирское высшее ордена Октябрьской Революции Краснознаменное училище радиоэлектроники ПВО имени Ленинского комсомола по специальности: командная тактическая, радиотехнические средства, квалификация: Инженер по эксплуатации радиотехнических средств. 21 июня 1986 г.</td>
		<td>«Охрана труда»</td>
		<td>Педагог</td>
	</tr>
	<tr>
		<td colspan="4">
			<b>Исайкин Федор Андреевич</b>
		</td>
	</tr>
	<tr>
		<td>12.09.1958</td>
		<td>Мордовский государственный университет имени Н.П. Огарева по специальности: Светотехника и света» 26 мая 1980 г. Факультет подготовки и переподготовки научно-педагогических кадров Академии МВД России 28 мая 1993 по специальности: «Технические средства управления и оргтехника», Московский институт пожарной безопасности МВД России Ученая степень кандидата технических наук 5 октября 1999 г.</td>
		<td>«Пожарно-технический минимум»</td>
		<td>Педагог</td>
	</tr>
	<tr>
		<td colspan="4">
			<b>Тищенко Валерия Сергеевна</b>
		</td>
	</tr>
	<tr>
		<td>31.07.1977</td>
		<td>Московская государственная юридическая академия по специальности: юриспруденция 15 июня 2000 г.</td>
		<td>«Пожарно-технический минимум»</td>
		<td>Педагог</td>
	</tr>
</table>
<br />
  <h2>7. Материально-техническое обеспечение и оснащенность образовательного процесса</h2>
  <h2><a href="/about/201.jpg"  class="fancybox" data-fancybox-group="gallery1"><img src="/about/201_mini.jpg" width="180" height="134" /></a>
 <a href="/about/202.jpg"  class="fancybox" data-fancybox-group="gallery1"><img src="/about/202_mini.jpg" width="180" height="134"  /></a>
 <a href="/about/203.jpg"  class="fancybox" data-fancybox-group="gallery1"><img src="/about/203_mini.jpg" width="180" height="134"  /></a>
 <a href="/about/204.jpg"  class="fancybox" data-fancybox-group="gallery1"><img src="/about/204_mini.jpg" width="180" height="134" /></a>
 <a href="/about/205.jpg"  class="fancybox" data-fancybox-group="gallery1"><img src="/about/205_mini.jpg" width="180" height="134"  /></a>
 <a href="/about/206.jpg"  class="fancybox" data-fancybox-group="gallery1"><img src="/about/206_mini.jpg" width="180" height="134"  /></a>
 </h2>

  <h2>8. Платные образовательные услуги</h2>
  Межрегиональный учебный центр предлагает обучение и повышение квалификации по следующим направлениям:
  <br/>
    <br/>
  <ul>
<li><a href="http://nousro.ru/program-ptm.php">Пожарно технический минимум <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
<li><a href="http://nousro.ru/pojarbez.php">Пожарная безопасность <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
<li><a href="http://ohrana-truda.nousro.ru/">Охрана труда <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
<li><a href="http://nousro.ru/stroi.php">Строительство <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
<li><a href="http://nousro.ru/jekologija.php">Экологическая безопасность <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
<li><a href="http://nousro.ru/proektirovanie.php">Проектирование <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
<li><a href="http://nousro.ru/gochs.php">Обучение ГО и ЧС <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
</ul>  

  <h2>9. Финансово-хозяйственная деятельность</h2>
<ul>
<li><a href="2013.pdf">Финансово-хозяйственная деятельность 2013 г. <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
<li><a href="2014.pdf">Финансово-хозяйственная деятельность 2014 г. <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
<li><a href="2015.pdf">Финансово-хозяйственная деятельность 2015 г. <img src="/upload/medialibrary/a83/ssylka.png"  width="10" height="10"  /></a></li>
</ul>  

  
<div> 
  <br />
 </div>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();

			/*
			 *  Different effects
			 */

			// Change title type, overlay closing speed
			$(".fancybox-effects-a").fancybox({
				helpers: {
					title : {
						type : 'outside'
					},
					overlay : {
						speedOut : 0
					}
				}
			});

			// Disable opening and closing animations, change title type
			$(".fancybox-effects-b").fancybox({
				openEffect  : 'none',
				closeEffect	: 'none',

				helpers : {
					title : {
						type : 'over'
					}
				}
			});

			// Set custom style, close if clicked, change title type and overlay color
			$(".fancybox-effects-c").fancybox({
				wrapCSS    : 'fancybox-custom',
				closeClick : true,

				openEffect : 'none',

				helpers : {
					title : {
						type : 'inside'
					},
					overlay : {
						css : {
							'background' : 'rgba(238,238,238,0.85)'
						}
					}
				}
			});

			// Remove padding, set opening and closing animations, close if clicked and disable overlay
			$(".fancybox-effects-d").fancybox({
				padding: 0,

				openEffect : 'elastic',
				openSpeed  : 150,

				closeEffect : 'elastic',
				closeSpeed  : 150,

				closeClick : true,

				helpers : {
					overlay : null
				}
			});

			/*
			 *  Button helper. Disable animations, hide close button, change title type and content
			 */

			$('.fancybox-buttons').fancybox({
				openEffect  : 'none',
				closeEffect : 'none',

				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,

				helpers : {
					title : {
						type : 'inside'
					},
					buttons	: {}
				},

				afterLoad : function() {
					this.title = 'Image ' + (this.index + 1) + ' of ' + this.group.length + (this.title ? ' - ' + this.title : '');
				}
			});


			/*
			 *  Thumbnail helper. Disable animations, hide close button, arrows and slide to next gallery item if clicked
			 */

			$('.fancybox-thumbs').fancybox({
				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,
				arrows    : false,
				nextClick : true,

				helpers : {
					thumbs : {
						width  : 50,
						height : 50
					}
				}
			});

			/*
			 *  Media helper. Group items, disable animations, hide arrows, enable media and button helpers.
			*/
			$('.fancybox-media')
				.attr('rel', 'media-gallery')
				.fancybox({
					openEffect : 'none',
					closeEffect : 'none',
					prevEffect : 'none',
					nextEffect : 'none',

					arrows : false,
					helpers : {
						media : {},
						buttons : {}
					}
				});

			/*
			 *  Open manually
			 */

			$("#fancybox-manual-a").click(function() {
				$.fancybox.open('1_b.jpg');
			});

			$("#fancybox-manual-b").click(function() {
				$.fancybox.open({
					href : 'iframe.html',
					type : 'iframe',
					padding : 5
				});
			});

			$("#fancybox-manual-c").click(function() {
				$.fancybox.open([
					{
						href : '1_b.jpg',
						title : 'My title'
					}, {
						href : '2_b.jpg',
						title : '2nd title'
					}, {
						href : '3_b.jpg'
					}
				], {
					helpers : {
						thumbs : {
							width: 75,
							height: 50
						}
					}
				});
			});


		});
	</script>
<script type="text/javascript">
$(document ).ready(function() {

$('.lupa2').mouseover(function(){

$('.lupa2').attr('src', '/bitrix/templates/content/img/zal1.jpg');


});
$('.lupa2').mouseout(function(){

$('.lupa2').attr('src', '/bitrix/templates/content/img/big3.jpg');


});


});


</script> 
<script type="text/javascript">
$(document ).ready(function() {

$('.lupa21').mouseover(function(){

$('.lupa21').attr('src', '/bitrix/templates/content/img/zal2.jpg');


});
$('.lupa21').mouseout(function(){

$('.lupa21').attr('src', '/bitrix/templates/content/img/big2.jpg');


});


});


</script> 
<script type="text/javascript">
$(document ).ready(function() {

$('.lupa31').mouseover(function(){

$('.lupa31').attr('src', '/bitrix/templates/content/img/zal3.jpg');


});
$('.lupa31').mouseout(function(){

$('.lupa31').attr('src', '/bitrix/templates/content/img/big1.jpg');


});


});


</script> 
 ﻿</div>

		</div>

		<div class="right_block">
				<a href="http://nousro.ru/contacts/"><span class="cont">+7 (495) 721-02-69 &nbsp; +7 (495) 780-79-93<br>
			Skype: mucdpo &nbsp; E-mail: info@nousro.ru
			</span>
			<a href="http://nousro.ru/contacts/"><img src="/bitrix/templates/content/img/phone_img.png" alt="" class="phone_img"></a>
<br />
									
			
			
			
			
						
			
						
						
						
						
			
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
			
						
						
						
						
						
						
						<div class="right_block1">
				<a href="/program.php"><p class="right_choose_kursi" class="choose_btn">курсы</p></a>
				<a href="/service.php"> <p class="right_choose_uslugi" class="choose_btn"> услуги</p></a>
					<ul class="right_block1_ul1">
						<li><a href="/program-ptm.php">ПТМ</a></li>
						<li><a href="/pojarbez.php">Пожарная безопасность</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/">Охрана труда</a></li>
						<li><a href="/stroi.php">Строительство</a></li>
						<li><a href="/jekologija.php">Экологическая безопасность</a></li>
						<li><a href="/proektirovanie.php">Проектирование</a></li>
						<li><a href="/gochs.php">Обучение ГО и ЧС</a></li>

					</ul>
					<ul class="right_block1_ul2">
						<li><a href="/mchs-edu.php">Обучение для лицензии МЧС</a></li>
						<li><a href="/licenzija-mchs.php">Лицензия МЧС</a></li>
						<li><a href="/arenda.php">Аренда оборудования МЧС</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/outsourcing-ohrana-truda.html">Аутсорсинг по охране труда</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/ohrana-truda.html">Организация охраны труда</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/attestacija-rabochih-mest.html">Оценка условий труда</a></li>
						<li><a href="/arenda-fstek.php">Оборудование для ФСТЭК</a></li>
						<li><a href="/perepodgotovka-specialistov.php">Переобучение специалистов</a></li>
											</ul>
				
			</div>
			            <div class="right_block3">
				<div class="kursi_btn1"><a href="/request/" onclick="yaCounter15488413.reachGoal('zayonline'); return true;" >ЗАЯВКА НА КУРСЫ <em>online</em></a></div>
				<div class="kursi_btn2"><a href="/upload/learning/zayavka.doc">ЗАЯВКА НА КУРСЫ <em>скачать</em></a></div>
				<img src="/bitrix/templates/content/img/paper_clip_icon.png"  style = "display: none";>
			</div>
			
			<div class="right_block2">
				<a href="/checkuser/">!&nbsp;&nbsp;&nbsp; ВЫДАННЫЕ УДОСТОВЕРЕНИЯ&nbsp;&nbsp;&nbsp; !</a></p>
			</div>
            <div class="right_block3">
				<div class="kursi_btn1"><a href="/clients/" onclick="yaCounter15488413.reachGoal('ourclients'); return true;" >НАШИ КЛИЕНТЫ</a></div>
				<div class="kursi_btn2"><a href="/clients/otzyvy.php" onclick="yaCounter15488413.reachGoal('otzyvy-btn'); return true;">ОТЗЫВЫ О НАС</a></div>
				
			</div>

			

			<div class="right_block4" style="cursor:pointer;" onclick="location.href='/doc/'; yaCounter15488413.reachGoal('shopap1'); return true;" > 
				<a href="/doc/">Учредительные<br>документы</a>
			</div>

			<div class="right_block5">
				<a href="/portal-postavchikov.php"><img src="/bitrix/templates/content/img/icon_block.jpg" alt=""></a>
			</div>

			<div class="right_block6">
			<a  onclick="yaCounter15488413.reachGoal('btn-karta'); return true;" href="/bitrix/templates/content/img/2map.jpg"  class="fancybox" data-fancybox-group="gallery"><img src="/bitrix/templates/content/img/icon_map.jpg" class="lupa" alt=""></a>
			</div>

			<div class="right_block7">
				<a href="/fotovideo.php"><img src="/bitrix/templates/content/img/fotobtn.png" alt=""></a>
			</div>

		</div>
		</div>

		<div class="footer_och-dist">
			<div class="inner">
				<div class="footer_items"><h3>Разделы сайта</h3>
					<ul>
						<li><a href="/">-Главная</a></li>
						<li><a href="/about/">-О нас</a></li>
						<li><a href="/filial/">-Филиалы</a></li>
						<li><a href="/clients/">-Клиенты</a></li>
						<li><a href="/doc/">-Документы</a></li>
						<li><a href="/faq/">-Вопрос-ответ</a></li>
						<li><a href="/sitemap/">-Карта сайта</a></li>
					</ul>
				</div>

				<div class="footer_items"><h3>Курсы</h3>
					<ul>
						<li><a href="/program-ptm.php">-ПТМ</a></li>
						<li><a href="/pojarbez.php">-Пожарная безопасность</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/">-Охрана труда</a></li>
						<li><a href="/stroi.php">-Строительство</a></li>
						<li><a href="/jekologija.php">-Экологическая безопасность</a></li>
						<li><a href="/proektirovanie.php">-Проектирование</a></li>
					</ul>
				</div>

				<div class="footer_items"><h3>Услуги</h3>
					<ul>
						<li><a href="/mchs-edu.php">-Обучение для лицензии МЧС</a></li>
						<li><a href="/licenzija-mchs.php">-Лицензия МЧС</a></li>
						<li><a href="/arenda.php">-Аренда оборудования МЧС</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/outsourcing-ohrana-truda.html">-Аутсорсинг по охране труда</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/ohrana-truda.html">-Организация охраны труда</a></li>
						<li><a href="http://ohrana-truda.nousro.ru/attestacija-rabochih-mest.html">-Специальная оценка условий труда</a></li>
						<li><a href="/arenda-fstek.php">-Аренда оборудования для ФСТЭК</a></li>		
					</ul>
				</div>

				<div class="footer_items"><h3>Документы</h3>
					<ul>
						<li><a href="/upload/doc/rbot/licenzija_obuchenija.pdf">-Лицензия НОЧУ ДПО "МУЦ"</a></li>
						<li><a href="/upload/doc/soglasovanije.pdf">-Согласование</a></li>
						<li><a href="/upload/doc/rbot/ustav_nou.pdf">-Устав НОЧУ ДПО "МУЦ"</a></li>
						<li><a href="/upload/doc/rbot/polojenie.pdf">-Положение НОЧУ ДПО "МУЦ"</a></li>
						<li><a href="/upload/doc/rbot/simvolika.pdf">-Символика НОЧУ ДПО "МУЦ"</a></li>
						<li><a href="/upload/doc/rbot/zakljuchenie_gpn.pdf">-Заключение ГПН</a></li>
						<li><a href="/upload/doc/rbot/zakljuchenie_sjez.pdf">-Санитарно-эпидемиологическое заключение</a></li>
						<li><a href="/doc/">-Список всех документов</a></li>
					</ul>
				</div>

				<div class="footer_items"><h3 class="h_social">МЫ В СОЦИАЛЬНЫХ СЕТЯХ</h3>
			
<br/>
			<table style="padding-top:12px;" width="200"><tr><td align="center" width="33%"><a target="_blank" href="https://plus.google.com/109379877916865389941/about"><img src="/bitrix/templates/content/img/google.png" width="20"></a></td><td align="center" width="33%"><a target="_blank" href="https://vk.com/nousro"><img src="/bitrix/templates/content/img/vk.png" width="20"></a></td><td align="center" width="33%"><a target="_blank" href="https://twitter.com/dpomuc"><img src="/bitrix/templates/content/img/twit.png" width="20"></a></td></tr></table>

		</div>
		
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'buevUrygEY';
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);})();</script>
<!-- {/literal} END JIVOSITE CODE -->
<!-- begin of Top100 code -->

 
  <div style="float: left;"> 
<script id="top100Counter" type="text/javascript" src="http://counter.rambler.ru/top100.jcn?2527820"></script>
 <noscript> <a href="http://top100.rambler.ru/navi/2527820/" > <img src="http://counter.rambler.ru/top100.cnt?2527820" alt="Rambler's Top100" border="0"  /> </a> </noscript> 
 
<!-- end of Top100 code -->
				        <!-- Yandex.Metrika informer -->
<a href="https://metrika.yandex.ru/stat/?id=15488413&amp;from=informer"
target="_blank" rel="nofollow"><img src="//bs.yandex.ru/informer/15488413/3_1_FFFFFFFF_EFEFEFFF_0_pageviews"
style="width:88px; height:31px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (просмотры, визиты и уникальные посетители)" onclick="try{Ya.Metrika.informer({i:this,id:15488413,lang:'ru'});return false}catch(e){}"/></a>
<!-- /Yandex.Metrika informer -->

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter15488413 = new Ya.Metrika({id:15488413,
                    webvisor:true,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true});
        } catch(e) { }
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/15488413" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
  </div>
			
		</div>
	</div>
</body>
</html>